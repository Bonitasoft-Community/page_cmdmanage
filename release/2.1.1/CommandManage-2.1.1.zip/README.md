Manage the command loaded in the engine.
All commands are visibles, and can be remove. A new command can be deploy

<img src="screenshot_commandmanagement.jpg"/>